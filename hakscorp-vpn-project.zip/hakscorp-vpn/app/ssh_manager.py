"""Minimal privileged boundary: sudo to one validated root-owned helper."""
import json, subprocess
from pathlib import Path
from app.security import check_username

HELPER = '/usr/local/libexec/hakscorp-ssh'

def helper(action: str, username: str, password: str | None = None):
    check_username(username)
    if action not in ('create','password','lock','unlock','delete','disconnect','sessions','limit'):
        raise ValueError('Acción inválida')
    # JSON supplied on stdin, never shell interpolated / argv credentials.
    data = json.dumps({'action': action, 'username': username, 'password': password})
    cmd = ['sudo','-n', HELPER]
    result = subprocess.run(cmd, input=data, text=True, capture_output=True, timeout=20, check=False)
    if result.returncode:
        raise RuntimeError('Acción de sistema fallida: ' + result.stderr.strip()[:160])
    return json.loads(result.stdout or '{}')

def create(username, password):
    return helper('create',username,password)

def change_password(username, password):
    return helper('password',username,password)

def delete(username):
    return helper('delete',username)

def lock(username):
    return helper('lock',username)

def unlock(username):
    return helper('unlock',username)

def disconnect(username):
    return helper('disconnect',username)

def sessions(username):
    return helper('sessions',username).get('sessions',0)

def limit(username, count):
    # No indiscriminate pkill: helper terminates only excess sshd session children.
    return helper('limit',username,str(count))
