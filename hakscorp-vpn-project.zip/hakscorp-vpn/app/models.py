from datetime import datetime, timezone
from sqlalchemy import create_engine, ForeignKey, String, Integer, DateTime, Boolean, Numeric, Text, UniqueConstraint, event
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker
from app.config import settings

def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)

class Base(DeclarativeBase):
    pass

class Reseller(Base):
    __tablename__ = 'resellers'
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(256))
    token_limit: Mapped[int] = mapped_column(Integer, default=0)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    valid_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    telegram_chat_id: Mapped[str | None] = mapped_column(String(50), unique=True, nullable=True)
    users: Mapped[list['SSHUser']] = relationship(back_populates='reseller')

class SSHUser(Base):
    __tablename__ = 'ssh_users'
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    credential_enc: Mapped[str] = mapped_column(Text)
    reseller_id: Mapped[int | None] = mapped_column(ForeignKey('resellers.id'), index=True)
    free_ip_hash: Mapped[str | None] = mapped_column(String(64), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    suspended: Mapped[bool] = mapped_column(Boolean, default=False)
    max_connections: Mapped[int] = mapped_column(Integer, default=1)
    reseller: Mapped[Reseller | None] = relationship(back_populates='users')

class Package(Base):
    __tablename__ = 'packages'
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    tokens: Mapped[int] = mapped_column(Integer)
    days: Mapped[int] = mapped_column(Integer)
    price: Mapped[float] = mapped_column(Numeric(12,2))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)

class Payment(Base):
    __tablename__ = 'payments'
    id: Mapped[int] = mapped_column(primary_key=True)
    external_reference: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    payment_id: Mapped[str | None] = mapped_column(String(80), unique=True)
    reseller_id: Mapped[int] = mapped_column(ForeignKey('resellers.id'))
    package_id: Mapped[int] = mapped_column(ForeignKey('packages.id'))
    expected_amount: Mapped[float] = mapped_column(Numeric(12,2))
    currency: Mapped[str] = mapped_column(String(6))
    status: Mapped[str] = mapped_column(String(20), default='pending')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime)

class Claim(Base):
    __tablename__ = 'claims'
    id: Mapped[int] = mapped_column(primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    ip_hash: Mapped[str] = mapped_column(String(64), index=True)
    requested_username: Mapped[str] = mapped_column(String(32))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime)

class Setting(Base):
    __tablename__ = 'settings'
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(Text, default='')

engine = create_engine(settings().database_url, connect_args={'check_same_thread': False, 'timeout': 30} if settings().database_url.startswith('sqlite') else {})
if settings().database_url.startswith('sqlite'):
    @event.listens_for(engine, 'connect')
    def pragma(dbapi_connection, connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute('PRAGMA foreign_keys=ON')
        cursor.execute('PRAGMA busy_timeout=30000')
        cursor.close()
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

def init_db():
    Base.metadata.create_all(engine)
