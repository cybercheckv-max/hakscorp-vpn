from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')
    domain: str = 'localhost'
    base_url: str = 'http://localhost:8000'
    database_url: str = 'sqlite:///./hakscorp.db'
    secret_key: str = ''
    credential_key: str = ''
    admin_username: str = 'admin'
    admin_password: str = ''
    session_https_only: bool = True
    trust_proxy: bool = False
    mp_access_token: str = ''
    mp_webhook_secret: str = ''
    mp_currency: str = 'BOB'
    telegram_bot_token: str = ''
    telegram_admin_chat_id: str = ''
    turnstile_site_key: str = ''
    turnstile_secret_key: str = ''
    shortener_provider_1: str = 'none'
    shortener_provider_2: str = 'none'
    ouo_api_key: str = ''
    shrinkearn_api_key: str = ''
    clksh_api_key: str = ''
    free_duration_hours: int = 12
    free_max_per_ip_24h: int = 1
    free_max_connections: int = 1
    min_claim_seconds: int = 45
    ssh_port: int = 22
    ssl_port: int = 443
    ws_port: int = 80

@lru_cache
def settings():
    return Settings()
