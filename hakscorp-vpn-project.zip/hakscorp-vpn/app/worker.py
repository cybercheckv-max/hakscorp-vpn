import asyncio, logging
from sqlalchemy import select
from app.models import SessionLocal, SSHUser, Reseller, utcnow
from app import ssh_manager as ssh

log=logging.getLogger(__name__)

def expire_users():
    with SessionLocal() as db:
        now=utcnow()
        users=db.scalars(select(SSHUser).where(SSHUser.expires_at<=now)).all()
        for user in users:
            try:
                ssh.delete(user.username)
                db.delete(user)
                db.commit()
            except Exception:
                db.rollback()
                log.exception('No fue posible expirar usuario %s',user.username)
        resellers=db.scalars(select(Reseller).where(Reseller.active==False)).all()
        for reseller in resellers:
            for user in db.scalars(select(SSHUser).where(SSHUser.reseller_id==reseller.id, SSHUser.suspended==False)).all():
                try:
                    ssh.lock(user.username)
                    user.suspended=True
                    db.commit()
                except Exception:
                    db.rollback()
                    log.exception('Error suspendiendo %s',user.username)
        expired=db.scalars(select(Reseller).where(Reseller.valid_until!=None,Reseller.valid_until<=now)).all()
        for reseller in expired:
            for user in db.scalars(select(SSHUser).where(SSHUser.reseller_id==reseller.id, SSHUser.suspended==False)).all():
                try:
                    ssh.lock(user.username)
                    user.suspended=True
                    db.commit()
                except Exception:
                    db.rollback()
                    log.exception('Error suspendiendo por vigencia %s',user.username)

def enforce_limits():
    with SessionLocal() as db:
        for user in db.scalars(select(SSHUser).where(SSHUser.expires_at>utcnow(),SSHUser.suspended==False)):
            try:
                ssh.limit(user.username,user.max_connections)
            except Exception:
                log.exception('Error comprobando límite %s',user.username)

async def main(stop):
    minute=0
    while not stop.is_set():
        await asyncio.to_thread(enforce_limits)
        if minute%10==0:
            await asyncio.to_thread(expire_users)
        minute+=1
        try:
            await asyncio.wait_for(stop.wait(),timeout=60)
        except asyncio.TimeoutError:
            pass
