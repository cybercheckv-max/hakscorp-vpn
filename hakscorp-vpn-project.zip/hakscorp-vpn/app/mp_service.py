import hmac, hashlib, secrets
from decimal import Decimal
from datetime import timedelta
import mercadopago
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from app.config import settings
from app.models import SessionLocal, Payment, Package, Reseller, utcnow

def sdk():
    if not settings().mp_access_token:
        raise HTTPException(503, 'Mercado Pago no configurado')
    return mercadopago.SDK(settings().mp_access_token)

def payment_link(reseller_id: int, package_id: int):
    with SessionLocal.begin() as db:
        seller=db.get(Reseller,reseller_id)
        package=db.get(Package,package_id)
        if not seller or not seller.active or not package or not package.enabled:
            raise HTTPException(400,'Paquete o cuenta no disponible')
        ref='hak_'+secrets.token_hex(20)
        record=Payment(external_reference=ref,reseller_id=reseller_id,package_id=package_id,expected_amount=package.price,currency=settings().mp_currency)
        db.add(record)
    pref={
        'items':[{'title':f'HakScorp VPN - {package.name}','quantity':1,'currency_id':settings().mp_currency,'unit_price':float(package.price)}],
        'external_reference':ref,
        'notification_url':settings().base_url.rstrip('/')+'/webhook/mercadopago',
    }
    result=sdk().preference().create(pref)
    if result.get('status') not in (200,201):
        raise HTTPException(502,'No se pudo generar preferencia de pago')
    url=result['response'].get('init_point')
    if not url: raise HTTPException(502,'Sin enlace de pago')
    return url

def verify_signature(x_signature: str, x_request_id: str, data_id: str):
    secret=settings().mp_webhook_secret
    if not secret or not x_signature or not x_request_id or not data_id:
        return False
    parts=dict(p.strip().split('=',1) for p in x_signature.split(',') if '=' in p)
    ts=parts.get('ts','')
    digest=parts.get('v1','')
    if not ts.isdecimal() or not digest:
        return False
    from time import time
    if abs(time()-int(ts)/1000)>600:
        return False
    manifest=f'id:{data_id};request-id:{x_request_id};ts:{ts};'
    expected=hmac.new(secret.encode(),manifest.encode(),hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected,digest)

def process_payment(payment_id: str):
    response=sdk().payment().get(payment_id)
    if response.get('status')!=200:
        raise HTTPException(502,'No fue posible comprobar el pago')
    info=response['response']
    if str(info.get('status'))!='approved':
        return None
    if str(info.get('id'))!=str(payment_id):
        raise HTTPException(400,'ID de pago inconsistente')
    reference=info.get('external_reference')
    if not reference: return None
    with SessionLocal.begin() as db:
        # SQLite serialized writes by immediate lock, ensuring two concurrent callbacks cannot both credit.
        if db.bind.dialect.name=='sqlite':
            db.connection().exec_driver_sql('BEGIN IMMEDIATE')
        payment=db.scalar(select(Payment).where(Payment.external_reference==reference))
        if not payment or payment.status=='approved':
            return None
        if db.scalar(select(Payment).where(Payment.payment_id==str(payment_id))):
            return None
        pack=db.get(Package,payment.package_id)
        reseller=db.get(Reseller,payment.reseller_id)
        if not pack or not reseller:
            return None
        if Decimal(str(info.get('transaction_amount','0')))!=Decimal(str(payment.expected_amount)):
            raise HTTPException(400,'Importe no coincide')
        if info.get('currency_id')!=payment.currency:
            raise HTTPException(400,'Moneda no coincide')
        payment.payment_id=str(payment_id)
        payment.status='approved'
        payment.approved_at=utcnow()
        reseller.token_limit+=pack.tokens
        base=max(reseller.valid_until or utcnow(),utcnow())
        reseller.valid_until=base+timedelta(days=pack.days)
        return {'reseller_id':reseller.id,'chat_id':reseller.telegram_chat_id,'username':reseller.username,'tokens':pack.tokens,'days':pack.days}
