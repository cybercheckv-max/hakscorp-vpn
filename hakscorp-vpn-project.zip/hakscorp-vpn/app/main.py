import asyncio, os, secrets, json, logging
from contextlib import asynccontextmanager
from datetime import timedelta
from pathlib import Path
from urllib.parse import quote
import httpx, psutil
from fastapi import FastAPI, Request, HTTPException, Depends, Form, Response
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from starlette.middleware.sessions import SessionMiddleware
from app.config import settings
from app.models import init_db, SessionLocal, Reseller, SSHUser, Package, Payment, Claim, Setting, utcnow
from app.security import hash_password, verify_password, check_username, encrypt, decrypt, digest, fresh_password, real_ip, ensure_config
from app import ssh_manager as ssh, shortener_service, mp_service, worker, telegram_bot

logging.basicConfig(level=logging.INFO)
log=logging.getLogger(__name__)
TEMPLATES=Jinja2Templates(directory=str(Path(__file__).parent/'templates'))
link_codes={}

@asynccontextmanager
async def lifespan(app):
    ensure_config()
    init_db()
    with SessionLocal.begin() as db:
        if not db.scalar(select(Reseller).where(Reseller.username==settings().admin_username)):
            db.add(Reseller(username=settings().admin_username,password_hash=hash_password(settings().admin_password),active=True,token_limit=0))
    stop=asyncio.Event()
    tasks=[asyncio.create_task(worker.main(stop))] if os.environ.get('RUN_WORKERS','1')=='1' else []
    if settings().telegram_bot_token and os.environ.get('RUN_WORKERS','1')=='1':
        tasks.append(asyncio.create_task(telegram_bot.polling_loop(stop)))
    try:
        yield
    finally:
        stop.set()
        await asyncio.gather(*tasks,return_exceptions=True)

app=FastAPI(title='HakScorp VPN',docs_url=None,redoc_url=None,lifespan=lifespan)
app.add_middleware(SessionMiddleware,secret_key=settings().secret_key or 'development-only',https_only=settings().session_https_only,same_site='lax',max_age=28800)

def db_session():
    with SessionLocal() as db:
        yield db

def current(request:Request,db=Depends(db_session)):
    user_id=request.session.get('user_id')
    if not user_id:
        raise HTTPException(401,'Inicia sesión')
    user=db.get(Reseller,user_id)
    if not user or not user.active or (user.username!=settings().admin_username and (not user.valid_until or user.valid_until<=utcnow())):
        raise HTTPException(403,'Cuenta suspendida o expirada')
    return user

def admin(user=Depends(current)):
    if user.username!=settings().admin_username:
        raise HTTPException(403,'Solo SuperAdmin')
    return user

def csrf(request):
    token=request.headers.get('x-csrf-token')
    if not token or not secrets.compare_digest(token,request.session.get('csrf','')):
        raise HTTPException(403,'CSRF inválido')

def render(request,name,**kwargs):
    return TEMPLATES.TemplateResponse(request,name,{'cfg':settings(),'csrf':request.session.get('csrf',''),'slots':ad_slots(),'is_admin':request.session.get('admin',False),**kwargs})

def ad_slots():
    with SessionLocal() as db:
        return {r.key:r.value for r in db.scalars(select(Setting).where(Setting.key.like('ad_%')))}

def user_json(user):
    now=utcnow()
    online=ssh.sessions(user.username)
    status='Expirado' if user.expires_at<=now else ('Suspendido' if user.suspended else (f'Online {online}/{user.max_connections}' if online else 'Activo'))
    return {'id':user.id,'username':user.username,'password':decrypt(user.credential_enc),'expires_at':user.expires_at.isoformat()+'Z','seconds_left':max(0,int((user.expires_at-now).total_seconds())),'status':status,'online':online,'max_connections':user.max_connections,'reseller_id':user.reseller_id}

def used_tokens(db,reseller_id):
    return db.scalar(select(func.count(SSHUser.id)).where(SSHUser.reseller_id==reseller_id,SSHUser.expires_at>utcnow(),SSHUser.suspended==False)) or 0

def own_user(db,user_id,owner):
    target=db.get(SSHUser,user_id)
    if not target or (owner.username!=settings().admin_username and target.reseller_id!=owner.id):
        raise HTTPException(404,'Usuario no encontrado')
    return target

class LoginIn(BaseModel):
    username:str
    password:str

@app.middleware('http')
async def browser_headers(request,call_next):
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='strict-origin-when-cross-origin'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Content-Security-Policy']="default-src 'self' https://cdn.tailwindcss.com https://challenges.cloudflare.com; script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://challenges.cloudflare.com https:; style-src 'self' 'unsafe-inline' https:; frame-src https:; img-src 'self' data: https:; connect-src 'self' https:; frame-ancestors 'none'"
    response.headers['Cache-Control']='no-store'
    return response

@app.get('/',response_class=HTMLResponse)
def index(request:Request):
    return render(request,'index.html')

@app.get('/login',response_class=HTMLResponse)
def login_page(request:Request):
    return render(request,'login.html')

@app.post('/api/login')
def login(data:LoginIn,request:Request,db=Depends(db_session)):
    user=db.scalar(select(Reseller).where(Reseller.username==data.username))
    if not user or not verify_password(data.password,user.password_hash) or not user.active:
        raise HTTPException(401,'Credenciales inválidas')
    request.session.clear()
    request.session['user_id']=user.id
    request.session['admin']=user.username==settings().admin_username
    request.session['csrf']=secrets.token_urlsafe(32)
    return {'ok':True,'csrf':request.session['csrf']}

@app.post('/api/logout')
def logout(request:Request):
    csrf(request)
    request.session.clear()
    return {'ok':True}

@app.get('/dashboard',response_class=HTMLResponse)
def dashboard(request:Request,user=Depends(current)):
    return render(request,'dashboard.html',user=user)

@app.get('/api/me')
def me(user=Depends(current),db=Depends(db_session)):
    return {'id':user.id,'username':user.username,'admin':user.username==settings().admin_username,'active':user.active,'token_limit':user.token_limit,'used_tokens':used_tokens(db,user.id),'valid_until':user.valid_until.isoformat()+'Z' if user.valid_until else None}

@app.get('/api/users')
def list_users(user=Depends(current),db=Depends(db_session)):
    query=select(SSHUser)
    if user.username!=settings().admin_username:
        query=query.where(SSHUser.reseller_id==user.id)
    return [user_json(item) for item in db.scalars(query.order_by(SSHUser.id.desc()))]

class CreateUser(BaseModel):
    username:str
    days:int=Field(ge=1,le=365)
    max_connections:int=Field(default=1,ge=1,le=10)

@app.post('/api/users')
def create_user(data:CreateUser,request:Request,user=Depends(current)):
    csrf(request)
    check_username(data.username)
    if user.username==settings().admin_username:
        raise HTTPException(400,'El administrador debe usar una cuenta de revendedor para crear usuarios')
    # SQLite write lock before checking available quota serializes concurrent creations.
    with SessionLocal() as db:
        if db.bind.dialect.name=='sqlite':
            db.connection().exec_driver_sql('BEGIN IMMEDIATE')
        owner=db.get(Reseller,user.id)
        if not owner or not owner.active or not owner.valid_until or owner.valid_until<=utcnow():
            raise HTTPException(403,'Cuenta sin vigencia')
        if used_tokens(db,owner.id)>=owner.token_limit:
            raise HTTPException(409,'No hay tokens disponibles')
        if db.scalar(select(SSHUser.id).where(SSHUser.username==data.username)):
            raise HTTPException(409,'Usuario ocupado')
        password=fresh_password()
        ssh.create(data.username,password)
        try:
            item=SSHUser(username=data.username,credential_enc=encrypt(password),reseller_id=owner.id,expires_at=utcnow()+timedelta(days=data.days),max_connections=data.max_connections)
            db.add(item); db.commit(); db.refresh(item)
        except Exception:
            db.rollback()
            try: ssh.delete(data.username)
            except Exception: log.exception('Limpieza SSH fallida')
            raise
        return user_json(item)

class EditUser(BaseModel):
    days: int | None = Field(default=None,ge=1,le=365)
    max_connections: int | None = Field(default=None,ge=1,le=10)
    password: str | None = Field(default=None,min_length=12,max_length=128)
    suspended: bool | None = None

@app.patch('/api/users/{user_id}')
def edit_user(user_id:int,data:EditUser,request:Request,user=Depends(current),db=Depends(db_session)):
    csrf(request)
    item=own_user(db,user_id,user)
    if item.reseller_id:
        reseller=db.get(Reseller,item.reseller_id)
        if data.suspended is False and (not reseller.active or not reseller.valid_until or reseller.valid_until<=utcnow()):
            raise HTTPException(403,'Revendedor sin vigencia')
        if data.suspended is False and item.suspended and used_tokens(db,reseller.id)>=reseller.token_limit:
            raise HTTPException(409,'No hay tokens disponibles')
    if data.password is not None:
        ssh.change_password(item.username,data.password)
        item.credential_enc=encrypt(data.password)
    if data.days is not None:
        if item.expires_at<=utcnow() and item.reseller_id and used_tokens(db,item.reseller_id)>=db.get(Reseller,item.reseller_id).token_limit:
            raise HTTPException(409,'No hay tokens disponibles')
        item.expires_at=max(utcnow(),item.expires_at)+timedelta(days=data.days)
    if data.max_connections is not None:
        item.max_connections=data.max_connections
    if data.suspended is not None and data.suspended!=item.suspended:
        if data.suspended: ssh.lock(item.username)
        else: ssh.unlock(item.username)
        item.suspended=data.suspended
    db.commit()
    return user_json(item)

@app.post('/api/users/{user_id}/disconnect')
def kick_user(user_id:int,request:Request,user=Depends(current),db=Depends(db_session)):
    csrf(request); item=own_user(db,user_id,user); ssh.disconnect(item.username)
    return {'ok':True}

@app.delete('/api/users/{user_id}')
def delete_user(user_id:int,request:Request,user=Depends(current),db=Depends(db_session)):
    csrf(request); item=own_user(db,user_id,user)
    ssh.delete(item.username); db.delete(item); db.commit()
    return {'ok':True}

class ResellerIn(BaseModel):
    username:str
    password:str=Field(min_length=12,max_length=128)
    token_limit:int=Field(default=0,ge=0,le=100000)
    validity_days:int=Field(default=30,ge=1,le=3650)

@app.get('/api/admin/resellers')
def resellers(user=Depends(admin),db=Depends(db_session)):
    return [{'id':r.id,'username':r.username,'active':r.active,'token_limit':r.token_limit,'used':used_tokens(db,r.id),'valid_until':r.valid_until.isoformat()+'Z' if r.valid_until else None,'telegram_chat_id':r.telegram_chat_id} for r in db.scalars(select(Reseller).where(Reseller.username!=settings().admin_username))]

@app.post('/api/admin/resellers')
def reseller_create(data:ResellerIn,request:Request,user=Depends(admin),db=Depends(db_session)):
    csrf(request); check_username(data.username)
    if db.scalar(select(Reseller).where(Reseller.username==data.username)):
        raise HTTPException(409,'Nombre ocupado')
    r=Reseller(username=data.username,password_hash=hash_password(data.password),token_limit=data.token_limit,valid_until=utcnow()+timedelta(days=data.validity_days))
    db.add(r); db.commit()
    return {'id':r.id}

class ResellerEdit(BaseModel):
    password: str | None = Field(default=None,min_length=12,max_length=128)
    token_delta: int = Field(default=0,ge=-100000,le=100000)
    validity_days: int | None = Field(default=None,ge=1,le=3650)
    active: bool | None = None

@app.patch('/api/admin/resellers/{reseller_id}')
def reseller_edit(reseller_id:int,data:ResellerEdit,request:Request,user=Depends(admin),db=Depends(db_session)):
    csrf(request)
    r=db.get(Reseller,reseller_id)
    if not r or r.username==settings().admin_username: raise HTTPException(404)
    if data.token_delta and r.token_limit+data.token_delta<used_tokens(db,r.id):
        raise HTTPException(409,'No puedes retirar tokens actualmente en uso')
    r.token_limit+=data.token_delta
    if data.password: r.password_hash=hash_password(data.password)
    if data.validity_days: r.valid_until=max(utcnow(),r.valid_until or utcnow())+timedelta(days=data.validity_days)
    if data.active is not None:
        if not data.active:
            for item in db.scalars(select(SSHUser).where(SSHUser.reseller_id==r.id,SSHUser.suspended==False)):
                ssh.lock(item.username); item.suspended=True
        r.active=data.active
    db.commit()
    return {'ok':True}

@app.delete('/api/admin/resellers/{reseller_id}')
def reseller_delete(reseller_id:int,request:Request,user=Depends(admin),db=Depends(db_session)):
    csrf(request)
    r=db.get(Reseller,reseller_id)
    if not r or r.username==settings().admin_username: raise HTTPException(404)
    for item in list(r.users):
        ssh.delete(item.username)
        db.delete(item)
    db.query(Payment).filter_by(reseller_id=r.id).update({'reseller_id':user.id})
    db.delete(r); db.commit()
    return {'ok':True}

class PackageIn(BaseModel):
    name:str=Field(min_length=1,max_length=100)
    tokens:int=Field(ge=1,le=100000)
    days:int=Field(ge=1,le=3650)
    price:float=Field(gt=0,le=1000000)
    enabled:bool=True

@app.get('/api/packages')
def packages(user=Depends(current),db=Depends(db_session)):
    return [{'id':p.id,'name':p.name,'tokens':p.tokens,'days':p.days,'price':str(p.price),'enabled':p.enabled} for p in db.scalars(select(Package)) if p.enabled or user.username==settings().admin_username]

@app.post('/api/admin/packages')
def package_create(data:PackageIn,request:Request,user=Depends(admin),db=Depends(db_session)):
    csrf(request); p=Package(**data.model_dump()); db.add(p); db.commit(); return {'id':p.id}

@app.patch('/api/admin/packages/{package_id}')
def package_edit(package_id:int,data:PackageIn,request:Request,user=Depends(admin),db=Depends(db_session)):
    csrf(request); p=db.get(Package,package_id)
    if not p: raise HTTPException(404)
    for key,value in data.model_dump().items(): setattr(p,key,value)
    db.commit(); return {'ok':True}

@app.delete('/api/admin/packages/{package_id}')
def package_delete(package_id:int,request:Request,user=Depends(admin),db=Depends(db_session)):
    csrf(request); p=db.get(Package,package_id)
    if not p: raise HTTPException(404)
    p.enabled=False; db.commit(); return {'ok':True}

@app.get('/api/admin/stats')
def stats(user=Depends(admin),db=Depends(db_session)):
    return {'cpu':psutil.cpu_percent(interval=.1),'ram':psutil.virtual_memory().percent,'ssh_online':sum(ssh.sessions(u.username) for u in db.scalars(select(SSHUser))),'approved_payments':db.scalar(select(func.count(Payment.id)).where(Payment.status=='approved')) or 0,'payments':[{'id':p.payment_id,'reference':p.external_reference,'amount':str(p.expected_amount),'currency':p.currency,'approved_at':p.approved_at.isoformat()+'Z' if p.approved_at else None} for p in db.scalars(select(Payment).where(Payment.status=='approved').order_by(Payment.id.desc()).limit(30))]}

@app.post('/api/telegram/link')
def telegram_link(request:Request,user=Depends(current)):
    csrf(request)
    code=secrets.token_urlsafe(15)
    link_codes[digest(code)]=(user.id,utcnow()+timedelta(minutes=10))
    return {'code':code,'expires_minutes':10}

@app.get('/api/admin/settings')
def admin_settings(user=Depends(admin),db=Depends(db_session)):
    return {x.key:x.value for x in db.scalars(select(Setting))}

class SettingsIn(BaseModel):
    ad_slot_top:str | None = None
    ad_slot_middle:str | None = None
    ad_slot_bottom:str | None = None
    ad_popunder:str | None = None
    free_duration_hours:int | None = Field(default=None,ge=1,le=72)
    free_max_per_ip_24h:int | None = Field(default=None,ge=1,le=10)
    free_max_connections:int | None = Field(default=None,ge=1,le=3)

@app.patch('/api/admin/settings')
def update_settings(data:SettingsIn,request:Request,user=Depends(admin),db=Depends(db_session)):
    csrf(request)
    for key,value in data.model_dump(exclude_none=True).items():
        if isinstance(value,str) and len(value)>16000: raise HTTPException(400,'Código publicitario demasiado largo')
        db.merge(Setting(key=key,value=str(value)))
    db.commit()
    return {'ok':True}

def get_setting(db,key,default):
    entry=db.get(Setting,key)
    return entry.value if entry else default

@app.get('/free',response_class=HTMLResponse)
def free_page(request:Request):
    return render(request,'free.html')

async def verify_turnstile(token,ip):
    if not settings().turnstile_secret_key or not settings().turnstile_site_key:
        raise HTTPException(503,'Turnstile no configurado')
    async with httpx.AsyncClient(timeout=10) as client:
        resp=await client.post('https://challenges.cloudflare.com/turnstile/v0/siteverify',data={'secret':settings().turnstile_secret_key,'response':token,'remoteip':ip})
    if resp.status_code!=200 or not resp.json().get('success'):
        raise HTTPException(400,'Verificación anti-bot fallida')

class ClaimStart(BaseModel):
    username:str
    turnstile_token:str

@app.post('/api/free/start')
async def free_start(data:ClaimStart,request:Request,db=Depends(db_session)):
    check_username(data.username)
    ip=real_ip(request)
    await verify_turnstile(data.turnstile_token,ip)
    hash_ip=digest(ip)
    max_per=int(get_setting(db,'free_max_per_ip_24h',str(settings().free_max_per_ip_24h)))
    used=db.scalar(select(func.count(SSHUser.id)).where(SSHUser.free_ip_hash==hash_ip,SSHUser.created_at>utcnow()-timedelta(hours=24))) or 0
    if used>=max_per: raise HTTPException(429,'Límite gratuito por IP alcanzado')
    if db.scalar(select(SSHUser.id).where(SSHUser.username==data.username)) or db.scalar(select(Claim.id).where(Claim.requested_username==data.username,Claim.consumed_at==None,Claim.expires_at>utcnow())):
        raise HTTPException(409,'Nombre ocupado')
    token=secrets.token_urlsafe(32)
    item=Claim(token_hash=digest(token),ip_hash=hash_ip,requested_username=data.username,expires_at=utcnow()+timedelta(minutes=15))
    db.add(item); db.commit()
    try:
        url=await shortener_service.generate(settings().base_url.rstrip('/')+'/claim/'+quote(token))
    except Exception:
        db.delete(item); db.commit(); raise
    return {'url':url,'expires_minutes':15}

@app.get('/claim/{token}',response_class=HTMLResponse)
def claim_page(token:str,request:Request,db=Depends(db_session)):
    claim=db.scalar(select(Claim).where(Claim.token_hash==digest(token)))
    if not claim or claim.expires_at<=utcnow() or claim.consumed_at:
        raise HTTPException(410,'Enlace vencido o usado')
    if claim.ip_hash!=digest(real_ip(request)):
        raise HTTPException(403,'IP no coincide')
    return render(request,'claim.html',token=token)

@app.post('/api/free/claim/{token}')
def claim_finish(token:str,request:Request,db=Depends(db_session)):
    iphash=digest(real_ip(request))
    with SessionLocal.begin() as lockdb:
        if lockdb.bind.dialect.name=='sqlite':
            lockdb.connection().exec_driver_sql('BEGIN IMMEDIATE')
        claim=lockdb.scalar(select(Claim).where(Claim.token_hash==digest(token)))
        if not claim or claim.consumed_at or claim.expires_at<=utcnow() or claim.ip_hash!=iphash:
            raise HTTPException(403,'Reclamación inválida')
        if (utcnow()-claim.created_at).total_seconds()<settings().min_claim_seconds:
            raise HTTPException(429,'Debes completar el tiempo de espera de publicidad')
        quota=int(get_setting(lockdb,'free_max_per_ip_24h',str(settings().free_max_per_ip_24h)))
        used=lockdb.scalar(select(func.count(SSHUser.id)).where(SSHUser.free_ip_hash==iphash,SSHUser.created_at>utcnow()-timedelta(hours=24))) or 0
        if used>=quota:
            raise HTTPException(429,'Límite por IP alcanzado')
        if lockdb.scalar(select(SSHUser.id).where(SSHUser.username==claim.requested_username)):
            raise HTTPException(409,'Nombre ya ocupado')
        duration=int(get_setting(lockdb,'free_duration_hours',str(settings().free_duration_hours)))
        connections=int(get_setting(lockdb,'free_max_connections',str(settings().free_max_connections)))
        if duration<1 or duration>72 or connections<1 or connections>3: raise HTTPException(500,'Configuración inválida')
        pwd=fresh_password()
        ssh.create(claim.requested_username,pwd)
        try:
            item=SSHUser(username=claim.requested_username,credential_enc=encrypt(pwd),free_ip_hash=iphash,expires_at=utcnow()+timedelta(hours=duration),max_connections=connections)
            lockdb.add(item)
            claim.consumed_at=utcnow()
            lockdb.flush()
        except Exception:
            ssh.delete(claim.requested_username)
            raise
    return {'host':settings().domain,'ssh_port':settings().ssh_port,'ssl_port':settings().ssl_port,'ws_port':settings().ws_port,'username':item.username,'password':pwd,'expires_at':item.expires_at.isoformat()+'Z'}

@app.post('/webhook/mercadopago')
async def mp_webhook(request:Request):
    # Authenticity depends on x-signature and server-side retrieval, never on the POST body status.
    payload=await request.json()
    data_id=request.query_params.get('data.id') or (payload.get('data') or {}).get('id')
    if not data_id: return {'ok':True}
    data_id=str(data_id)
    if not mp_service.verify_signature(request.headers.get('x-signature',''),request.headers.get('x-request-id',''),data_id):
        raise HTTPException(401,'Firma inválida')
    if str(payload.get('type') or request.query_params.get('type')) not in ('payment','None'):
        return {'ok':True}
    info=await asyncio.to_thread(mp_service.process_payment,data_id)
    if info: await telegram_bot.notify_payment(info)
    return {'ok':True}
