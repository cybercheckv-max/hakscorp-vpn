from urllib.parse import urlencode
import httpx
from fastapi import HTTPException
from app.config import settings

# Providers may change their external APIs; failures are fail-closed.
ENDPOINTS={
    'ouo':('https://ouo.io/api/', 'ouo_api_key','text'),
    'shrinkearn':('https://shrinkearn.com/api', 'shrinkearn_api_key','json'),
    'clksh':('https://clk.sh/api', 'clksh_api_key','json'),
}

async def shorten_once(url: str, provider: str):
    if provider=='none':
        return url
    if provider not in ENDPOINTS:
        raise HTTPException(503,'Acortador desconocido')
    endpoint,attr,format_=ENDPOINTS[provider]
    key=getattr(settings(),attr)
    if not key:
        raise HTTPException(503,'API key faltante para acortador')
    async with httpx.AsyncClient(timeout=12,follow_redirects=False) as client:
        result=await client.get(endpoint,params={'key':key,'url':url})
    if result.status_code!=200:
        raise HTTPException(502,'Acortador externo falló')
    if format_=='text':
        candidate=result.text.strip()
    else:
        try:
            payload=result.json()
            candidate=payload.get('shortenedUrl') or payload.get('shortened_url') or payload.get('short_url') or payload.get('url') or ''
            if isinstance(payload.get('result'),dict):
                candidate=payload['result'].get('shortenedUrl') or payload['result'].get('short_url') or candidate
        except (ValueError,TypeError,AttributeError):
            candidate=''
    from urllib.parse import urlsplit
    parsed=urlsplit(candidate)
    if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password:
        raise HTTPException(502,'El acortador devolvió una URL inválida')
    return candidate

async def generate(url: str):
    # Reverse wrapping: browser visits provider 1 then provider 2 then claim.
    providers=[settings().shortener_provider_1,settings().shortener_provider_2]
    providers=[x for x in providers if x!='none']
    if not providers:
        raise HTTPException(503,'Configura un acortador para habilitar las cuentas gratuitas')
    for provider in reversed(providers):
        url=await shorten_once(url,provider)
    return url
