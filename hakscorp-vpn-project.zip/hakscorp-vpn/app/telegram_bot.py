import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, Bot
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from app.config import settings
from app.models import SessionLocal, Reseller, Package, SSHUser, utcnow
from app.mp_service import payment_link

async def account(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat=str(update.effective_chat.id)
    with SessionLocal() as db:
        reseller=db.query(Reseller).filter_by(telegram_chat_id=chat).first()
        if not reseller:
            await update.effective_message.reply_text('Vincula tu Telegram desde tu panel con /vincular <código>.')
            return
        used=db.query(SSHUser).filter_by(reseller_id=reseller.id,suspended=False).filter(SSHUser.expires_at>utcnow()).count()
        await update.effective_message.reply_text(f'Cuenta: {reseller.username}\nTokens: {used}/{reseller.token_limit}\nVigencia: {reseller.valid_until or "Sin vigencia"}')

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('HakScorp VPN: /cuenta, /recargar, /vincular CODIGO')

async def recharge(update: Update, context: ContextTypes.DEFAULT_TYPE):
    with SessionLocal() as db:
        reseller=db.query(Reseller).filter_by(telegram_chat_id=str(update.effective_chat.id),active=True).first()
        packages=db.query(Package).filter_by(enabled=True).all()
        if not reseller:
            await update.effective_message.reply_text('Primero vincula tu cuenta desde el panel.')
            return
        buttons=[[InlineKeyboardButton(f'{p.name}: {p.tokens} tokens / {p.days} días / {p.price} {settings().mp_currency}',callback_data=f'buy:{p.id}')] for p in packages]
    await update.effective_message.reply_text('Selecciona un paquete:',reply_markup=InlineKeyboardMarkup(buttons) if buttons else None)

async def buy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    with SessionLocal() as db:
        reseller=db.query(Reseller).filter_by(telegram_chat_id=str(update.effective_chat.id),active=True).first()
        reseller_id=reseller.id if reseller else None
    if not reseller_id:
        await update.effective_message.reply_text('Cuenta no vinculada')
        return
    try:
        url=await asyncio.to_thread(payment_link,reseller_id,int(update.callback_query.data.split(':')[1]))
        await update.effective_message.reply_text(f'Paga aquí: {url}')
    except Exception:
        await update.effective_message.reply_text('No se pudo crear el pago. Contacta al administrador.')

async def link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text('Uso: /vincular CODIGO')
        return
    from app.security import digest
    code=digest(context.args[0])
    from app.main import link_codes
    # A shared in-memory code is suitable only for the single-process deployment.
    record=link_codes.pop(code,None)
    if not record or record[1]<utcnow():
        await update.message.reply_text('Código inválido o expirado')
        return
    with SessionLocal.begin() as db:
        seller=db.get(Reseller,record[0])
        if seller:
            seller.telegram_chat_id=str(update.effective_chat.id)
    await update.message.reply_text('Telegram vinculado correctamente')

async def notify_payment(info):
    token=settings().telegram_bot_token
    if not token:
        return
    async with Bot(token) as bot:
        message=f'Pago aprobado: {info["username"]}, +{info["tokens"]} tokens, +{info["days"]} días.'
        for chat in set(filter(None,[info.get('chat_id'),settings().telegram_admin_chat_id])):
            try:
                await bot.send_message(chat_id=chat,text=message)
            except Exception:
                pass

def create_app():
    app=Application.builder().token(settings().telegram_bot_token).build()
    app.add_handler(CommandHandler('start',start))
    app.add_handler(CommandHandler('cuenta',account))
    app.add_handler(CommandHandler('recargar',recharge))
    app.add_handler(CommandHandler('vincular',link))
    app.add_handler(CallbackQueryHandler(buy,pattern=r'^buy:\d+$'))
    return app

async def polling_loop(stop: asyncio.Event):
    app=create_app()
    async with app:
        await app.start()
        await app.updater.start_polling(drop_pending_updates=True)
        try:
            await stop.wait()
        finally:
            await app.updater.stop()
            await app.stop()
