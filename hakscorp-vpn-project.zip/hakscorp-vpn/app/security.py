import re, secrets, hmac, hashlib
from datetime import datetime, timedelta
from cryptography.fernet import Fernet
from fastapi import HTTPException, Request
from pwdlib import PasswordHash
from app.config import settings

ph = PasswordHash.recommended()
USERNAME = re.compile(r'^[a-z][a-z0-9_]{2,23}$')

def check_username(value):
    if not USERNAME.fullmatch(value) or value in ('root','admin','daemon','nobody','sshd','ubuntu','www-data','hakscorp') or value.startswith('hs_'):
        raise HTTPException(400, 'Usuario no permitido (3-24 caracteres, minúsculas, dígitos y _)')
    return value

def hash_password(password):
    return ph.hash(password)

def verify_password(password, digest):
    return ph.verify(password, digest)

def cipher():
    return Fernet(settings().credential_key.encode())

def encrypt(value):
    return cipher().encrypt(value.encode()).decode()

def decrypt(value):
    return cipher().decrypt(value.encode()).decode()

def digest(value):
    return hmac.new(settings().secret_key.encode(), value.encode(), hashlib.sha256).hexdigest()

def real_ip(request: Request):
    # Only trust X-Real-IP after nginx overwrites it; Uvicorn binds to 127.0.0.1.
    if settings().trust_proxy and request.client and request.client.host in ('127.0.0.1','::1'):
        return request.headers.get('x-real-ip') or request.client.host
    return request.client.host if request.client else 'unknown'

def fresh_password():
    return secrets.token_urlsafe(18)

def ensure_config():
    cfg = settings()
    if len(cfg.secret_key) < 48 or not cfg.credential_key or not cfg.admin_password or cfg.admin_password == 'REPLACE_ME':
        raise RuntimeError('Configura SECRET_KEY, CREDENTIAL_KEY y ADMIN_PASSWORD en .env')
