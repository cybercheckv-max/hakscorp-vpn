from datetime import timedelta
from app.security import check_username, digest
from app.models import utcnow
from app.mp_service import verify_signature
import pytest
from fastapi import HTTPException

def test_username_validation():
    assert check_username('usuario123')=='usuario123'
    for user in ('root','../../etc/passwd','A','a b','sshd','hs_hidden'):
        with pytest.raises(HTTPException): check_username(user)

def test_token_digest_stable(monkeypatch):
    monkeypatch.setenv('SECRET_KEY','a'*64)
    from app.config import settings
    settings.cache_clear()
    assert digest('hello')==digest('hello')
    assert digest('hello')!=digest('world')
    settings.cache_clear()

def test_invalid_payment_signature():
    assert not verify_signature('','','123')

def test_time():
    assert utcnow()+timedelta(seconds=5)>utcnow()
